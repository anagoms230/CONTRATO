from flask import Flask, request, send_file
from flask_cors import CORS
from docxtpl import DocxTemplate
import os
import tempfile

app = Flask(__name__)
CORS(app)

@app.route('/api/gerar-contrato', methods=['POST'])
def gerar_contrato():
    data = request.get_json()

    doc = DocxTemplate("modelo_contrato.docx")
    doc.render(data)

    with tempfile.NamedTemporaryFile(delete=False, suffix=".docx") as tmp:
        nome_arquivo = tmp.name
        doc.save(nome_arquivo)

    return send_file(nome_arquivo, as_attachment=True, download_name="contrato_gerado.docx")

if __name__ == "__main__":
    app.run(debug=True)